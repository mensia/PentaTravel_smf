<!DOCTYPE html>
<html lang="en-US">
<head>
<meta property="og:url" content="https://wanderers.qodeinteractive.com/typeahead.js" />
<meta property="og:type" content="article" />
<meta property="og:title" content="Wanderers" />
<meta property="og:description" content="An Adventurous Theme for Travel and Tourism" />
<meta property="og:image" content="https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/img/open_graph.jpg" />
<meta charset="UTF-8" />
<link rel="profile" href="https://gmpg.org/xfn/11" />
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=yes">
<title>Page not found &#8211; Wanderers</title>
<script type="application/javascript">var mkdfToursAjaxURL = "https://wanderers.qodeinteractive.com/wp-admin/admin-ajax.php"</script><meta name='robots' content='max-image-preview:large' />

<script data-cfasync="false" data-pagespeed-no-defer>//<![CDATA[
	var gtm4wp_datalayer_name = "dataLayer";
	var dataLayer = dataLayer || [];
//]]>
</script>
<link rel='dns-prefetch' href='//apis.google.com' />
<link rel='dns-prefetch' href='//export.qodethemes.com' />
<link rel='dns-prefetch' href='//maps.googleapis.com' />
<link rel='dns-prefetch' href='//static.zdassets.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Wanderers &raquo; Feed" href="https://wanderers.qodeinteractive.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Wanderers &raquo; Comments Feed" href="https://wanderers.qodeinteractive.com/comments/feed/" />
<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/wanderers.qodeinteractive.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.2"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://wanderers.qodeinteractive.com/wp-includes/css/dist/block-library/style.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wc-blocks-vendors-style-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-vendors-style.css?ver=6.3.3' type='text/css' media='all' />
<link rel='stylesheet' id='wc-blocks-style-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-style.css?ver=6.3.3' type='text/css' media='all' />
<link rel='stylesheet' id='titan-adminbar-styles-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/anti-spam/assets/css/admin-bar.css?ver=7.2.9' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mikado-membership-style-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/mkdf-membership/assets/css/membership.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mikado-membership-responsive-style-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/mkdf-membership/assets/css/membership-responsive.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mkdf-modules-css' href='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/css/modules.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mkdf-tours-style-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/mkdf-tours/assets/css/tours.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mkdf-modules-responsive-css' href='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/css/modules-responsive.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mkdf-tours-responsive-style-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/mkdf-tours/assets/css/tours-responsive.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='nouislider-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/mkdf-tours/assets/css/nouislider.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='rabbit_css-css' href='https://export.qodethemes.com/_toolbar/assets/css/rbt-modules.css?ver=5.8.2' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='ppress-frontend-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/css/frontend.min.css?ver=3.2.5' type='text/css' media='all' />
<link rel='stylesheet' id='ppress-flatpickr-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/flatpickr/flatpickr.min.css?ver=3.2.5' type='text/css' media='all' />
<link rel='stylesheet' id='ppress-select2-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/select2/select2.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='swiper-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/plugins/swiper/swiper.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='qi-addons-for-elementor-grid-style-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/css/grid.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='qi-addons-for-elementor-helper-parts-style-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/css/helper-parts.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='qi-addons-for-elementor-style-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/css/main.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mkdf-default-style-css' href='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/style.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mikado-font_awesome-css' href='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/css/font-awesome/css/font-awesome.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mikado-font_elegant-css' href='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/css/elegant-icons/style.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mikado-ion_icons-css' href='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/css/ion-icons/css/ionicons.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mikado-linea_icons-css' href='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/css/linea-icons/style.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mikado-linear_icons-css' href='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/css/linear-icons/style.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mikado-simple_line_icons-css' href='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/css/simple-line-icons/simple-line-icons.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mikado-dripicons-css' href='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/css/dripicons/dripicons.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='mediaelement-css' href='https://wanderers.qodeinteractive.com/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css?ver=4.2.16' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css' href='https://wanderers.qodeinteractive.com/wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mkdf-woo-css' href='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/css/woocommerce.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mkdf-woo-responsive-css' href='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/css/woocommerce-responsive.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mkdf-style-dynamic-css' href='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/css/style_dynamic.css?ver=1642591980' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mkdf-style-dynamic-responsive-css' href='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/css/style_dynamic_responsive.css?ver=1642591980' type='text/css' media='all' />
<link rel='stylesheet' id='wanderers-mkdf-google-fonts-css' href='https://fonts.googleapis.com/css?family=Cabin%3A300%2C400%2C500%2C600%2C700%2C900%7CPlayfair+Display%3A300%2C400%2C500%2C600%2C700%2C900%7CMontserrat%3A300%2C400%2C500%2C600%2C700%2C900%7CKristi%3A300%2C400%2C500%2C600%2C700%2C900&#038;subset=latin-ext&#038;ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='mkdf-core-dashboard-style-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/mkdf-core/core-dashboard/assets/css/core-dashboard.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='qode-zendesk-chat-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/qode-zendesk-chat//assets/main.css?ver=5.8.2' type='text/css' media='all' />
<script type='text/javascript' src='https://apis.google.com/js/platform.js' id='wanderers-mikado-membership-google-plus-api-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/revslider/public/assets/js/rbtools.min.js?ver=6.5.12' async id='tp-tools-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.5.12' async id='revmin-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.6.0.0' id='jquery-blockui-js'></script>
<script type='text/javascript' id='wc-add-to-cart-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/wanderers.qodeinteractive.com\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=6.0.0' id='wc-add-to-cart-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/flatpickr/flatpickr.min.js?ver=5.8.2' id='ppress-flatpickr-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/select2/select2.min.js?ver=5.8.2' id='ppress-select2-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=6.8.0' id='vc_woocommerce-add-to-cart-js-js'></script>
<link rel="https://api.w.org/" href="https://wanderers.qodeinteractive.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://wanderers.qodeinteractive.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://wanderers.qodeinteractive.com/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 5.8.2" />
<meta name="generator" content="WooCommerce 6.0.0" />

<script data-cfasync="false" data-pagespeed-no-defer>//<![CDATA[
	var dataLayer_content = [];
	dataLayer.push( dataLayer_content );//]]>
</script>
<script data-cfasync="false">//<![CDATA[
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.'+'js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KTQ2BTD');//]]>
</script>

 <noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress." />
<meta name="generator" content="Powered by Slider Revolution 6.5.12 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/favicon-dark.png" sizes="32x32" />
<link rel="icon" href="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/favicon-dark.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/favicon-dark.png" />
<meta name="msapplication-TileImage" content="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/favicon-dark.png" />
<script>function setREVStartSize(e){
			//window.requestAnimationFrame(function() {
				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;
				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;
				try {
					var pw = document.getElementById(e.c).parentNode.offsetWidth,
						newh;
					pw = pw===0 || isNaN(pw) ? window.RSIW : pw;
					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);
					if(e.layout==="fullscreen" || e.l==="fullscreen")
						newh = Math.max(e.mh,window.RSIH);
					else{
						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];
						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];
											
						var nl = new Array(e.rl.length),
							ix = 0,
							sl;
						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;
						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
						sl = nl[0];
						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}
						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);
						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
					}
					var el = document.getElementById(e.c);
					if (el!==null && el) el.style.height = newh+"px";
					el = document.getElementById(e.c+"_wrapper");
					if (el!==null && el) {
						el.style.height = newh+"px";
						el.style.display = "block";
					}
				} catch(e){
					console.log("Failure at Presize of Slider:" + e)
				}
			//});
		  };</script>
<style type="text/css" id="wp-custom-css">
			.widget.widget_categories ul li.cat-item-51{
display: none;
} 

.mkdf-woo-single-page .star-rating::after {
content: '';
background-color: #fff;
width: 1px;
height: 100%;
position: absolute;
right: 0;
}
		</style>
<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>
<body class="error404 theme-wanderers mkdf-core-1.3 mkdf-social-login-1.0.2 mkdf-tours-1.0.5 woocommerce-no-js qodef-qi--no-touch qi-addons-for-elementor-1.5.1 wanderers-ver-1.8 mkdf-grid-1300 mkdf-disable-global-padding-bottom mkdf-light-header mkdf-sticky-header-on-scroll-down-up mkdf-dropdown-animate-height mkdf-header-standard mkdf-menu-area-shadow-disable mkdf-menu-area-in-grid-shadow-disable mkdf-menu-area-border-disable mkdf-menu-area-in-grid-border-disable mkdf-logo-area-border-disable mkdf-header-vertical-shadow-disable mkdf-header-vertical-border-disable mkdf-side-menu-slide-from-right mkdf-woocommerce-columns-3 mkdf-woo-small-space mkdf-woo-pl-info-below-image mkdf-woo-single-thumb-on-left-side mkdf-woo-single-has-pretty-photo mkdf-default-mobile-header mkdf-sticky-up-mobile-header mkdf-search-covers-header wpb-js-composer js-comp-ver-6.8.0 vc_responsive elementor-default elementor-kit-2360" itemscope itemtype="http://schema.org/WebPage">
<section class="mkdf-side-menu">
<div class="mkdf-close-side-menu-holder">
<a class="mkdf-close-side-menu" href="#" target="_self">
<span aria-hidden="true" class="mkdf-icon-font-elegant icon_close "></span> </a>
</div>
<div id="media_image-2" class="widget mkdf-sidearea widget_media_image"><a href="https://wanderers.qodeinteractive.com"><img width="162" height="52" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/logo-sidearea.png" class="image wp-image-1467  attachment-full size-full" alt="logo" loading="lazy" style="max-width: 100%; height: auto;" /></a></div><div class="widget mkdf-custom-font-widget"><p class="mkdf-custom-font-holder  mkdf-cf-5156  " style="font-size: 18px;line-height: 30px;color: #b4b4b4;margin: 20px 0px 35px" data-item-class="mkdf-cf-5156">
Proin gravida nibh vel velit auctor aliquet. Aenean sollic itudin, lorem quis bibendum auctornisi elit consequat ipsum, nec nibh id elit. Lorem ipsum dolor.</p></div><div id="text-12" class="widget mkdf-sidearea widget_text"><div class="mkdf-widget-title-holder"><h5 class="mkdf-widget-title">Latest Posts</h5></div> <div class="textwidget"></div>
</div><div class="widget mkdf-separator-widget"><div class="mkdf-separator-holder clearfix  mkdf-separator-center mkdf-separator-normal">
<div class="mkdf-separator" style="border-style: solid;margin-top: 0px;margin-bottom: 2px"></div>
</div>
</div><div class="widget mkdf-blog-list-widget"><div class="mkdf-blog-list-holder mkdf-bl-simple mkdf-bl-one-column mkdf-small-space mkdf-bl-pag-no-pagination" data-type=simple data-number-of-posts=2 data-number-of-columns=1 data-space-between-items=small data-orderby=date data-order=DESC data-image-size=thumbnail data-title-tag=h5 data-excerpt-length=40 data-post-info-section=yes data-post-info-image=yes data-post-info-author=yes data-post-info-date=yes data-post-info-category=yes data-post-info-comments=no data-post-info-like=no data-post-info-share=no data-pagination-type=no-pagination data-max-num-pages=20 data-next-page=2>
<div class="mkdf-bl-wrapper mkdf-outer-space">
<ul class="mkdf-blog-list">
<li class="mkdf-bl-item mkdf-item-space clearfix">
<div class="mkdf-bli-inner">
<div class="mkdf-post-image">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/solo-traveler-learns-on-the-road/" title="Solo Traveler Learns On The Road">
<img width="150" height="150" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/blog-post-1-150x150.jpg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="a" loading="lazy" srcset="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/blog-post-1-150x150.jpg 150w, https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/blog-post-1-550x550.jpg 550w, https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/blog-post-1-100x100.jpg 100w" sizes="(max-width: 150px) 100vw, 150px" /> </a>
</div>
<div class="mkdf-bli-content">
<h5 itemprop="name" class="entry-title mkdf-post-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/solo-traveler-learns-on-the-road/" title="Solo Traveler Learns On The Road">
Solo Traveler Learns On The Road </a>
</h5> <div itemprop="dateCreated" class="mkdf-post-info-date entry-date published updated">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/2018/03/">
<span class="icon_calendar"></span> March 8, 2018 </a>
<meta itemprop="interactionCount" content="UserComments: 0" />
</div> </div>
</div>
</li><li class="mkdf-bl-item mkdf-item-space clearfix">
<div class="mkdf-bli-inner">
<div class="mkdf-post-image">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/use-your-social-network-to-travel/" title="Use Your Social Network To Travel">
<img width="150" height="150" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/blog-post-4-150x150.jpg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="a" loading="lazy" srcset="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/blog-post-4-150x150.jpg 150w, https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/blog-post-4-550x550.jpg 550w, https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/blog-post-4-100x100.jpg 100w" sizes="(max-width: 150px) 100vw, 150px" /> </a>
</div>
<div class="mkdf-bli-content">
<h5 itemprop="name" class="entry-title mkdf-post-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/use-your-social-network-to-travel/" title="Use Your Social Network To Travel">
Use Your Social Network To Travel </a>
</h5> <div itemprop="dateCreated" class="mkdf-post-info-date entry-date published updated">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/2018/03/">
<span class="icon_calendar"></span> March 7, 2018 </a>
<meta itemprop="interactionCount" content="UserComments: 0" />
</div> </div>
</div>
</li> </ul>
</div>
</div></div><div id="text-13" class="widget mkdf-sidearea widget_text"> <div class="textwidget"><p><div class="mkdf-iwt clearfix  mkdf-iwt-icon-left mkdf-iwt-icon-tiny">
<a itemprop="url" href="tel:167712444227" target="_blank" rel="noopener">
<div class="mkdf-iwt-icon">
<span class="mkdf-icon-shortcode mkdf-normal   mkdf-icon-tiny" data-hover-color="#ffcc05" data-color="#9b9b9b">
<span aria-hidden="true" class="mkdf-icon-font-elegant icon_phone mkdf-icon-element" style="color: #9b9b9b;font-size:14px"></span> </span>
</div>
<div class="mkdf-iwt-content" style="padding-left: 14px">
<h6 class="mkdf-iwt-title" style="color: #9b9b9b;margin-top: 10px">
<span class="mkdf-iwt-title-text">1-677-124-44227</span>
</h6>
</div>
</a>
</div><div class="vc_empty_space" style="height: 4px"><span class="vc_empty_space_inner"></span></div><div class="mkdf-iwt clearfix  mkdf-iwt-icon-left mkdf-iwt-icon-tiny">
<a itemprop="url" href="/cdn-cgi/l/email-protection#4631272822233423343506372922232f283223342725322f30236825292b" target="_self" rel="noopener">
<div class="mkdf-iwt-icon">
<span class="mkdf-icon-shortcode mkdf-normal   mkdf-icon-tiny" data-hover-color="#ffcc05" data-color="#9b9b9b">
<span aria-hidden="true" class="mkdf-icon-font-elegant icon_mail mkdf-icon-element" style="color: #9b9b9b;font-size:14px"></span> </span>
</div>
<div class="mkdf-iwt-content" style="padding-left: 14px">
<h6 class="mkdf-iwt-title" style="color: #9b9b9b;margin-top: 10px">
<span class="mkdf-iwt-title-text"><span class="__cf_email__" data-cfemail="a1d6c0cfc5c4d3c4d3d2e1d0cec5c4c8cfd5c4d3c0c2d5c8d7c48fc2cecc">[email&#160;protected]</span></span>
</h6>
</div>
</a>
</div></p>
</div>
</div><div class="widget mkdf-separator-widget"><div class="mkdf-separator-holder clearfix  mkdf-separator-center mkdf-separator-normal">
<div class="mkdf-separator" style="border-style: solid;margin-top: 0px;margin-bottom: 2px"></div>
</div>
</div>
<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover" data-hover-color="#ffcc05" style="color: #808285;;font-size: 13px;margin: 0px 8px 0px 0px;" href="https://twitter.com/QodeInteractive" target="_blank">
<span class="mkdf-social-icon-widget  social_twitter    "></span> </a>
<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover" data-hover-color="#ffcc05" style="color: #808285;;font-size: 13px;margin: 0px 8px;" href="https://www.facebook.com/QodeInteractive/" target="_blank">
<span class="mkdf-social-icon-widget  social_facebook    "></span> </a>
<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover" data-hover-color="#ffcc05" style="color: #808285;;font-size: 13px;margin: 0px 8px;" href="https://www.instagram.com/qodeinteractive/" target="_blank">
<span class="mkdf-social-icon-widget  social_instagram    "></span> </a>
<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover" data-hover-color="#ffcc05" style="color: #808285;;font-size: 13px;margin: 0px 8px;" href="https://www.tumblr.com" target="_blank">
<span class="mkdf-social-icon-widget  social_tumblr    "></span> </a>
<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover" data-hover-color="#ffcc05" style="color: #808285;;font-size: 13px;margin: 0px 8px;" href="https://www.linkedin.com/company/qode-themes/" target="_blank">
<span class="mkdf-social-icon-widget  social_linkedin    "></span> </a>
<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover" data-hover-color="#ffcc05" style="color: #808285;;font-size: 13px;margin: 0px 8px;" href="https://www.pinterest.com/qodeinteractive/" target="_blank">
<span class="mkdf-social-icon-widget  social_pinterest    "></span> </a>
</section>
<div class="mkdf-wrapper">
<div class="mkdf-wrapper-inner">
<header class="mkdf-page-header">
<div class="mkdf-menu-area mkdf-menu-right">
<div class="mkdf-grid">
<div class="mkdf-vertical-align-containers">
<div class="mkdf-position-left">
<div class="mkdf-position-left-inner">
<div class="mkdf-logo-wrapper">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/" style="height: 41px;">
<img itemprop="image" class="mkdf-normal-logo" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/logo-dark.png" width="256" height="82" alt="logo" />
<img itemprop="image" class="mkdf-dark-logo" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/logo-dark.png" width="256" height="82" alt="dark logo" /> <img itemprop="image" class="mkdf-light-logo" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/logo-light.png" width="256" height="82" alt="light logo" /> </a>
</div>
</div>
</div>
<div class="mkdf-position-right">
<div class="mkdf-position-right-inner">
<nav class="mkdf-main-menu mkdf-drop-down mkdf-default-nav">
<ul id="menu-main-menu" class="clearfix"><li id="nav-menu-item-34" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home  narrow"><a href="https://wanderers.qodeinteractive.com/" class=""><span class="item_outer"><span class="item_text">Home</span></span></a></li>
<li id="nav-menu-item-40" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Pages</span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-637" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/about-us/" class=""><span class="item_outer"><span class="item_text">About Us</span></span></a></li>
<li id="nav-menu-item-914" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/our-team/" class=""><span class="item_outer"><span class="item_text">Our Team</span></span></a></li>
<li id="nav-menu-item-815" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/contact/" class=""><span class="item_outer"><span class="item_text">Contact</span></span></a></li>
<li id="nav-menu-item-915" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/faq/" class=""><span class="item_outer"><span class="item_text">FAQ</span></span></a></li>
<li id="nav-menu-item-816" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/coming-soon/" class=""><span class="item_outer"><span class="item_text">Coming Soon</span></span></a></li>
<li id="nav-menu-item-633" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/404" class=""><span class="item_outer"><span class="item_text">404</span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-41" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Destinations</span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-312" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/destination-list/" class=""><span class="item_outer"><span class="item_text">Destination List</span></span></a></li>
<li id="nav-menu-item-42" class="menu-item menu-item-type-post_type menu-item-object-destinations "><a href="https://wanderers.qodeinteractive.com/destinations/thailand/" class=""><span class="item_outer"><span class="item_text">Destination Item</span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-43" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Tours</span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-86" class="menu-item menu-item-type-post_type menu-item-object-tour-item "><a href="https://wanderers.qodeinteractive.com/tour-item/ultimate-thailand/" class=""><span class="item_outer"><span class="item_text">Tour Single</span></span></a></li>
<li id="nav-menu-item-319" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Tour Lists</span></span></a>
<ul>
<li id="nav-menu-item-2273" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/tour-search-page/?view_type=standard" class=""><span class="item_outer"><span class="item_text">Standard</span></span></a></li>
<li id="nav-menu-item-2274" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/tour-search-page/?view_type=gallery" class=""><span class="item_outer"><span class="item_text">Gallery</span></span></a></li>
<li id="nav-menu-item-333" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/tour-list-carousel/" class=""><span class="item_outer"><span class="item_text">Carousel</span></span></a></li>
<li id="nav-menu-item-2275" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/tour-search-page/?view_type=list" class=""><span class="item_outer"><span class="item_text">Search Page</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-1281" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Dashboard</span></span></a>
<ul>
<li id="nav-menu-item-1284" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/dashboard/?user-action=profile" class=""><span class="item_outer"><span class="item_text">My Profile</span></span></a></li>
<li id="nav-menu-item-1282" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/dashboard/?user-action=edit-profile" class=""><span class="item_outer"><span class="item_text">Edit Profile</span></span></a></li>
<li id="nav-menu-item-1283" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/dashboard/?user-action=my-bookings" class=""><span class="item_outer"><span class="item_text">My Bookings</span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="nav-menu-item-45" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Blog</span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-525" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/blog-list/" class=""><span class="item_outer"><span class="item_text">Standard List</span></span></a></li>
<li id="nav-menu-item-625" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/blog-masonry/" class=""><span class="item_outer"><span class="item_text">Masonry List</span></span></a></li>
<li id="nav-menu-item-516" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Single</span></span></a>
<ul>
<li id="nav-menu-item-515" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/solo-traveler-learns-on-the-road/" class=""><span class="item_outer"><span class="item_text">Standard Post</span></span></a></li>
<li id="nav-menu-item-547" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/new-ways-to-become-a-better-travel-blogger/" class=""><span class="item_outer"><span class="item_text">Gallery Post</span></span></a></li>
<li id="nav-menu-item-546" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/use-your-social-network-to-travel/" class=""><span class="item_outer"><span class="item_text">Audio Post</span></span></a></li>
<li id="nav-menu-item-543" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/travel-the-world-in-only-20-days/" class=""><span class="item_outer"><span class="item_text">Video Post</span></span></a></li>
<li id="nav-menu-item-544" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/best-designed-wordpress-themes/" class=""><span class="item_outer"><span class="item_text">Link Post</span></span></a></li>
<li id="nav-menu-item-545" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/marc-nicolaus-richmond/" class=""><span class="item_outer"><span class="item_text">Quote Post</span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="nav-menu-item-46" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Shop</span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-39" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/shop/" class=""><span class="item_outer"><span class="item_text">List</span></span></a></li>
<li id="nav-menu-item-362" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://wanderers.qodeinteractive.com/shop/biking-helmet/" class=""><span class="item_outer"><span class="item_text">Single</span></span></a></li>
<li id="nav-menu-item-47" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Shop Pages</span></span></a>
<ul>
<li id="nav-menu-item-36" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/my-account/" class=""><span class="item_outer"><span class="item_text">My account</span></span></a></li>
<li id="nav-menu-item-37" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/checkout/" class=""><span class="item_outer"><span class="item_text">Checkout</span></span></a></li>
<li id="nav-menu-item-38" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/cart/" class=""><span class="item_outer"><span class="item_text">Cart</span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="nav-menu-item-44" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub wide"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Elements</span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-1195" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Featured</span></span></a>
<ul>
<li id="nav-menu-item-1194" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tour-list-standard/" class=""><span class="item_outer"><span class="item_text">Tour List Standard</span></span></a></li>
<li id="nav-menu-item-1409" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tour-list-gallery/" class=""><span class="item_outer"><span class="item_text">Tour List Gallery</span></span></a></li>
<li id="nav-menu-item-1408" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tour-list-masonry/" class=""><span class="item_outer"><span class="item_text">Tour List Masonry</span></span></a></li>
<li id="nav-menu-item-1419" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tour-carousel/" class=""><span class="item_outer"><span class="item_text">Tour Carousel</span></span></a></li>
<li id="nav-menu-item-1539" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tour-filter/" class=""><span class="item_outer"><span class="item_text">Tour Filter</span></span></a></li>
<li id="nav-menu-item-1499" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/destination-list-shortcode-2/" class=""><span class="item_outer"><span class="item_text">Destination List</span></span></a></li>
<li id="nav-menu-item-1190" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/parallax-sections/" class=""><span class="item_outer"><span class="item_text">Parallax Sections</span></span></a></li>
<li id="nav-menu-item-1189" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/video-button/" class=""><span class="item_outer"><span class="item_text">Video Button</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-1196" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Classic</span></span></a>
<ul>
<li id="nav-menu-item-1217" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/accordions-and-toogles/" class=""><span class="item_outer"><span class="item_text">Accordions &#038; Toogles</span></span></a></li>
<li id="nav-menu-item-1229" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tabs/" class=""><span class="item_outer"><span class="item_text">Tabs</span></span></a></li>
<li id="nav-menu-item-1228" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/buttons/" class=""><span class="item_outer"><span class="item_text">Buttons</span></span></a></li>
<li id="nav-menu-item-1216" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/icon-with-text/" class=""><span class="item_outer"><span class="item_text">Icon With Text</span></span></a></li>
<li id="nav-menu-item-1839" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/icon-list/" class=""><span class="item_outer"><span class="item_text">Icon List</span></span></a></li>
<li id="nav-menu-item-1226" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/google-maps/" class=""><span class="item_outer"><span class="item_text">Google Maps</span></span></a></li>
<li id="nav-menu-item-1215" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/contact-form/" class=""><span class="item_outer"><span class="item_text">Contact Form</span></span></a></li>
<li id="nav-menu-item-1213" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/clients/" class=""><span class="item_outer"><span class="item_text">Clients</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-1197" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Infographic</span></span></a>
<ul>
<li id="nav-menu-item-1255" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/counters/" class=""><span class="item_outer"><span class="item_text">Counters</span></span></a></li>
<li id="nav-menu-item-1254" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/countdown/" class=""><span class="item_outer"><span class="item_text">Countdown</span></span></a></li>
<li id="nav-menu-item-1248" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/progress-bar/" class=""><span class="item_outer"><span class="item_text">Progress Bar</span></span></a></li>
<li id="nav-menu-item-1246" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/blog-list/" class=""><span class="item_outer"><span class="item_text">Blog List</span></span></a></li>
<li id="nav-menu-item-1192" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/team/" class=""><span class="item_outer"><span class="item_text">Team</span></span></a></li>
<li id="nav-menu-item-1214" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/top-reviews/" class=""><span class="item_outer"><span class="item_text">Top Reviews</span></span></a></li>
<li id="nav-menu-item-1971" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/call-to-action/" class=""><span class="item_outer"><span class="item_text">Call To Action</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-1198" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Typography</span></span></a>
<ul>
<li id="nav-menu-item-1279" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/headings/" class=""><span class="item_outer"><span class="item_text">Headings</span></span></a></li>
<li id="nav-menu-item-1278" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/columns/" class=""><span class="item_outer"><span class="item_text">Columns</span></span></a></li>
<li id="nav-menu-item-1277" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/blockquote/" class=""><span class="item_outer"><span class="item_text">Blockquote</span></span></a></li>
<li id="nav-menu-item-1276" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/dropcaps/" class=""><span class="item_outer"><span class="item_text">Dropcaps</span></span></a></li>
<li id="nav-menu-item-1275" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/highlights/" class=""><span class="item_outer"><span class="item_text">Highlights</span></span></a></li>
<li id="nav-menu-item-1274" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/separators/" class=""><span class="item_outer"><span class="item_text">Separators</span></span></a></li>
<li id="nav-menu-item-1273" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/title-subtitle/" class=""><span class="item_outer"><span class="item_text">Title &#038; Subtitle</span></span></a></li>
<li id="nav-menu-item-1272" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/custom-font/" class=""><span class="item_outer"><span class="item_text">Custom Font</span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
</ul></nav>
<div class="mkdf-shopping-cart-holder" style="padding: 0 13px 0px">
<div class="mkdf-shopping-cart-inner">
<a itemprop="url" class="mkdf-header-cart" href="https://wanderers.qodeinteractive.com/cart/">
<span class="mkdf-cart-icon icon_bag_alt"></span>
<span class="mkdf-cart-number">13</span>
</a>
<div class="mkdf-shopping-cart-dropdown">
<ul>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/winter-shoes/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-3-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/winter-shoes/">Winter Shoes</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>128.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=70c639df5e30bdee440e4cdf599fec2b&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/ski-goggles/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-5-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/ski-goggles/">Ski Goggles</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>45.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=8cb22bdd0b7ba1ab13d742e22eed8da2&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/hd-boards/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-6-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/hd-boards/">HD Boards</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>250.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=f4f6dce2f3a0f9dada0c2b5b66452017&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/hiking-shoes/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-8-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/hiking-shoes/">Hiking Shoes</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>125.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=25b2822c2f5a3230abfadd476e8b04c9&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/snowboard-2/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-7-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/snowboard-2/">Snowboard</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>212.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=3c7781a36bcd6cf08c11a970fbe0e2a6&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/winter-beanie/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-9-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/winter-beanie/">Winter Beanie</a>
</h5>
<span class="mkdf-quantity">2x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>36.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=2421fcb1263b9530df88f7f002e78ea5&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/wrist-warmer/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-10-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/wrist-warmer/">Wrist Warmer</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>15.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=fccb60fb512d13df5083790d64c4d5dd&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/ski-gloves/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-11-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/ski-gloves/">Ski Gloves</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>62.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=1651cf0d2f737d7adeab84d339dbabd3&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/black-glasses/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-12-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/black-glasses/">Black Glasses</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>47.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=d61e4bbd6393c9111e6526ea173a7c8b&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/snowboard/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-7-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/snowboard/">Snowboard</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>112.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=9461cce28ebe3e76fb4b931c35a169b0&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/travel-map-2/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-14-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/travel-map-2/">Travel Map</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>17.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=c3c59e5f8b3e9753913f4d435b53c308&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/black-glasses-2/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-12-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/black-glasses-2/">Black Glasses</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>147.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=7d04bbbe5494ae9d2f5a76aa1c00fa2f&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li class="mkdf-cart-bottom">
<div class="mkdf-subtotal-holder clearfix">
<span class="mkdf-total">Total:</span>
<span class="mkdf-total-amount">
<span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#036;</span>1,232.00</span> </span>
</div>
<div class="mkdf-btn-holder clearfix">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/checkout/" class="mkdf-checkout">CHECKOUT</a>
<a itemprop="url" href="https://wanderers.qodeinteractive.com/cart/" class="mkdf-view-cart">VIEW CART</a>
</div>
</li>
</ul>
</div>
</div>
</div>
<a style="margin: 0 21px 0px 14px;" class="mkdf-search-opener mkdf-icon-has-hover" href="javascript:void(0)">
<span class="mkdf-search-opener-wrapper">
<span aria-hidden="true" class="mkdf-icon-font-elegant icon_search "></span> </span>
</a>
<a class="mkdf-side-menu-button-opener mkdf-icon-has-hover" href="javascript:void(0)">
<span class="mkdf-side-menu-icon">
<span aria-hidden="true" class="mkdf-icon-font-elegant icon_menu "></span> </span>
</a>
</div>
</div>
</div>
</div>
</div>
<div class="mkdf-sticky-header">
<div class="mkdf-sticky-holder mkdf-menu-right">
<div class="mkdf-grid">
<div class="mkdf-vertical-align-containers">
<div class="mkdf-position-left">
<div class="mkdf-position-left-inner">
<div class="mkdf-logo-wrapper">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/" style="height: 41px;">
<img itemprop="image" class="mkdf-normal-logo" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/logo-dark.png" width="256" height="82" alt="logo" />
<img itemprop="image" class="mkdf-dark-logo" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/logo-dark.png" width="256" height="82" alt="dark logo" /> <img itemprop="image" class="mkdf-light-logo" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/logo-light.png" width="256" height="82" alt="light logo" /> </a>
</div>
</div>
</div>
<div class="mkdf-position-right">
<div class="mkdf-position-right-inner">
<nav class="mkdf-main-menu mkdf-drop-down mkdf-sticky-nav">
<ul id="menu-main-menu-1" class="clearfix"><li id="sticky-nav-menu-item-34" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home  narrow"><a href="https://wanderers.qodeinteractive.com/" class=""><span class="item_outer"><span class="item_text">Home</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-40" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Pages</span><span class="plus"></span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-637" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/about-us/" class=""><span class="item_outer"><span class="item_text">About Us</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-914" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/our-team/" class=""><span class="item_outer"><span class="item_text">Our Team</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-815" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/contact/" class=""><span class="item_outer"><span class="item_text">Contact</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-915" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/faq/" class=""><span class="item_outer"><span class="item_text">FAQ</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-816" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/coming-soon/" class=""><span class="item_outer"><span class="item_text">Coming Soon</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-633" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/404" class=""><span class="item_outer"><span class="item_text">404</span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-41" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Destinations</span><span class="plus"></span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-312" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/destination-list/" class=""><span class="item_outer"><span class="item_text">Destination List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-42" class="menu-item menu-item-type-post_type menu-item-object-destinations "><a href="https://wanderers.qodeinteractive.com/destinations/thailand/" class=""><span class="item_outer"><span class="item_text">Destination Item</span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-43" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Tours</span><span class="plus"></span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-86" class="menu-item menu-item-type-post_type menu-item-object-tour-item "><a href="https://wanderers.qodeinteractive.com/tour-item/ultimate-thailand/" class=""><span class="item_outer"><span class="item_text">Tour Single</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-319" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Tour Lists</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-2273" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/tour-search-page/?view_type=standard" class=""><span class="item_outer"><span class="item_text">Standard</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2274" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/tour-search-page/?view_type=gallery" class=""><span class="item_outer"><span class="item_text">Gallery</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-333" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/tour-list-carousel/" class=""><span class="item_outer"><span class="item_text">Carousel</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2275" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/tour-search-page/?view_type=list" class=""><span class="item_outer"><span class="item_text">Search Page</span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-1281" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Dashboard</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-1284" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/dashboard/?user-action=profile" class=""><span class="item_outer"><span class="item_text">My Profile</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1282" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/dashboard/?user-action=edit-profile" class=""><span class="item_outer"><span class="item_text">Edit Profile</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1283" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/dashboard/?user-action=my-bookings" class=""><span class="item_outer"><span class="item_text">My Bookings</span><span class="plus"></span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-45" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Blog</span><span class="plus"></span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-525" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/blog-list/" class=""><span class="item_outer"><span class="item_text">Standard List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-625" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/blog-masonry/" class=""><span class="item_outer"><span class="item_text">Masonry List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-516" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Single</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-515" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/solo-traveler-learns-on-the-road/" class=""><span class="item_outer"><span class="item_text">Standard Post</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-547" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/new-ways-to-become-a-better-travel-blogger/" class=""><span class="item_outer"><span class="item_text">Gallery Post</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-546" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/use-your-social-network-to-travel/" class=""><span class="item_outer"><span class="item_text">Audio Post</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-543" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/travel-the-world-in-only-20-days/" class=""><span class="item_outer"><span class="item_text">Video Post</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-544" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/best-designed-wordpress-themes/" class=""><span class="item_outer"><span class="item_text">Link Post</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-545" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/marc-nicolaus-richmond/" class=""><span class="item_outer"><span class="item_text">Quote Post</span><span class="plus"></span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-46" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Shop</span><span class="plus"></span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-39" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/shop/" class=""><span class="item_outer"><span class="item_text">List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-362" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://wanderers.qodeinteractive.com/shop/biking-helmet/" class=""><span class="item_outer"><span class="item_text">Single</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-47" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Shop Pages</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-36" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/my-account/" class=""><span class="item_outer"><span class="item_text">My account</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-37" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/checkout/" class=""><span class="item_outer"><span class="item_text">Checkout</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-38" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/cart/" class=""><span class="item_outer"><span class="item_text">Cart</span><span class="plus"></span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-44" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub wide"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Elements</span><span class="plus"></span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-1195" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Featured</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-1194" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tour-list-standard/" class=""><span class="item_outer"><span class="item_text">Tour List Standard</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1409" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tour-list-gallery/" class=""><span class="item_outer"><span class="item_text">Tour List Gallery</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1408" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tour-list-masonry/" class=""><span class="item_outer"><span class="item_text">Tour List Masonry</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1419" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tour-carousel/" class=""><span class="item_outer"><span class="item_text">Tour Carousel</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1539" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tour-filter/" class=""><span class="item_outer"><span class="item_text">Tour Filter</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1499" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/destination-list-shortcode-2/" class=""><span class="item_outer"><span class="item_text">Destination List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1190" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/parallax-sections/" class=""><span class="item_outer"><span class="item_text">Parallax Sections</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1189" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/video-button/" class=""><span class="item_outer"><span class="item_text">Video Button</span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-1196" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Classic</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-1217" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/accordions-and-toogles/" class=""><span class="item_outer"><span class="item_text">Accordions &#038; Toogles</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1229" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tabs/" class=""><span class="item_outer"><span class="item_text">Tabs</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1228" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/buttons/" class=""><span class="item_outer"><span class="item_text">Buttons</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1216" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/icon-with-text/" class=""><span class="item_outer"><span class="item_text">Icon With Text</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1839" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/icon-list/" class=""><span class="item_outer"><span class="item_text">Icon List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1226" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/google-maps/" class=""><span class="item_outer"><span class="item_text">Google Maps</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1215" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/contact-form/" class=""><span class="item_outer"><span class="item_text">Contact Form</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1213" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/clients/" class=""><span class="item_outer"><span class="item_text">Clients</span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-1197" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Infographic</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-1255" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/counters/" class=""><span class="item_outer"><span class="item_text">Counters</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1254" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/countdown/" class=""><span class="item_outer"><span class="item_text">Countdown</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1248" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/progress-bar/" class=""><span class="item_outer"><span class="item_text">Progress Bar</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1246" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/blog-list/" class=""><span class="item_outer"><span class="item_text">Blog List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1192" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/team/" class=""><span class="item_outer"><span class="item_text">Team</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1214" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/top-reviews/" class=""><span class="item_outer"><span class="item_text">Top Reviews</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1971" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/call-to-action/" class=""><span class="item_outer"><span class="item_text">Call To Action</span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-1198" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Typography</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-1279" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/headings/" class=""><span class="item_outer"><span class="item_text">Headings</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1278" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/columns/" class=""><span class="item_outer"><span class="item_text">Columns</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1277" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/blockquote/" class=""><span class="item_outer"><span class="item_text">Blockquote</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1276" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/dropcaps/" class=""><span class="item_outer"><span class="item_text">Dropcaps</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1275" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/highlights/" class=""><span class="item_outer"><span class="item_text">Highlights</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1274" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/separators/" class=""><span class="item_outer"><span class="item_text">Separators</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1273" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/title-subtitle/" class=""><span class="item_outer"><span class="item_text">Title &#038; Subtitle</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1272" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/custom-font/" class=""><span class="item_outer"><span class="item_text">Custom Font</span><span class="plus"></span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
</ul></nav>
<div class="mkdf-shopping-cart-holder" style="padding: 0 13px 0px">
<div class="mkdf-shopping-cart-inner">
<a itemprop="url" class="mkdf-header-cart" href="https://wanderers.qodeinteractive.com/cart/">
<span class="mkdf-cart-icon icon_bag_alt"></span>
<span class="mkdf-cart-number">13</span>
</a>
<div class="mkdf-shopping-cart-dropdown">
<ul>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/winter-shoes/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-3-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/winter-shoes/">Winter Shoes</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>128.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=70c639df5e30bdee440e4cdf599fec2b&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/ski-goggles/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-5-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/ski-goggles/">Ski Goggles</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>45.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=8cb22bdd0b7ba1ab13d742e22eed8da2&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/hd-boards/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-6-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/hd-boards/">HD Boards</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>250.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=f4f6dce2f3a0f9dada0c2b5b66452017&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/hiking-shoes/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-8-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/hiking-shoes/">Hiking Shoes</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>125.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=25b2822c2f5a3230abfadd476e8b04c9&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/snowboard-2/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-7-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/snowboard-2/">Snowboard</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>212.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=3c7781a36bcd6cf08c11a970fbe0e2a6&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/winter-beanie/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-9-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/winter-beanie/">Winter Beanie</a>
</h5>
<span class="mkdf-quantity">2x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>36.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=2421fcb1263b9530df88f7f002e78ea5&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/wrist-warmer/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-10-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/wrist-warmer/">Wrist Warmer</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>15.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=fccb60fb512d13df5083790d64c4d5dd&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/ski-gloves/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-11-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/ski-gloves/">Ski Gloves</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>62.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=1651cf0d2f737d7adeab84d339dbabd3&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/black-glasses/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-12-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/black-glasses/">Black Glasses</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>47.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=d61e4bbd6393c9111e6526ea173a7c8b&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/snowboard/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-7-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/snowboard/">Snowboard</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>112.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=9461cce28ebe3e76fb4b931c35a169b0&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/travel-map-2/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-14-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/travel-map-2/">Travel Map</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>17.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=c3c59e5f8b3e9753913f4d435b53c308&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li>
<div class="mkdf-item-image-holder">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/black-glasses-2/">
<img width="450" height="450" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/product-12-450x450.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" /> </a>
</div>
<div class="mkdf-item-info-holder">
<h5 itemprop="name" class="mkdf-product-title">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/shop/black-glasses-2/">Black Glasses</a>
</h5>
<span class="mkdf-quantity">1x</span>
<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>147.00</bdi></span> <a href="https://wanderers.qodeinteractive.com/cart/?remove_item=7d04bbbe5494ae9d2f5a76aa1c00fa2f&#038;_wpnonce=0524328e9c" class="remove" title="Remove this item"><span class="icon-arrows-remove"></span></a> </div>
</li>
<li class="mkdf-cart-bottom">
<div class="mkdf-subtotal-holder clearfix">
<span class="mkdf-total">Total:</span>
<span class="mkdf-total-amount">
<span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#036;</span>1,232.00</span> </span>
</div>
<div class="mkdf-btn-holder clearfix">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/checkout/" class="mkdf-checkout">CHECKOUT</a>
<a itemprop="url" href="https://wanderers.qodeinteractive.com/cart/" class="mkdf-view-cart">VIEW CART</a>
</div>
</li>
</ul>
</div>
</div>
</div>
<a style="margin: 0 21px 0px 14px;" class="mkdf-search-opener mkdf-icon-has-hover" href="javascript:void(0)">
<span class="mkdf-search-opener-wrapper">
<span aria-hidden="true" class="mkdf-icon-font-elegant icon_search "></span> </span>
</a>
<a class="mkdf-side-menu-button-opener mkdf-icon-has-hover" href="javascript:void(0)">
<span class="mkdf-side-menu-icon">
<span aria-hidden="true" class="mkdf-icon-font-elegant icon_menu "></span> </span>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
<form action="https://wanderers.qodeinteractive.com/" class="mkdf-search-cover" method="get">
<div class="mkdf-container">
<div class="mkdf-container-inner clearfix">
<div class="mkdf-form-holder-outer">
<div class="mkdf-form-holder">
<div class="mkdf-form-holder-inner">
<span class="icon_search"></span>
<input type="text" placeholder="Search on site..." name="s" class="mkdf_search_field" autocomplete="off" />
<a class="mkdf-search-close" href="#">
<span aria-hidden="true" class="mkdf-icon-font-elegant icon_close "></span> </a>
</div>
</div>
</div>
</div>
</div>
</form></header>
<header class="mkdf-mobile-header">
<div class="mkdf-mobile-header-inner">
<div class="mkdf-mobile-header-holder">
<div class="mkdf-grid">
<div class="mkdf-vertical-align-containers">
<div class="mkdf-vertical-align-containers">
<div class="mkdf-mobile-menu-opener">
<a href="javascript:void(0)">
<span class="mkdf-mobile-menu-icon">
<span aria-hidden="true" class="mkdf-icon-font-elegant icon_menu "></span> </span>
</a>
</div>
<div class="mkdf-position-center">
<div class="mkdf-position-center-inner">
<div class="mkdf-mobile-logo-wrapper">
<a itemprop="url" href="https://wanderers.qodeinteractive.com/" style="height: 41px">
<img itemprop="image" src="https://wanderers.qodeinteractive.com/wp-content/uploads/2018/02/logo-dark.png" width="256" height="82" alt="Mobile Logo" />
</a>
</div>
</div>
</div>
<div class="mkdf-position-right">
<div class="mkdf-position-right-inner">
</div>
</div>
</div>
</div>
</div>
</div>
<nav class="mkdf-mobile-nav" role="navigation" aria-label="Mobile Menu">
<div class="mkdf-grid">
<ul id="menu-main-menu-2" class=""><li id="mobile-menu-item-34" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://wanderers.qodeinteractive.com/" class=""><span>Home</span></a></li>
<li id="mobile-menu-item-40" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Pages</span></h6><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-637" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/about-us/" class=""><span>About Us</span></a></li>
<li id="mobile-menu-item-914" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/our-team/" class=""><span>Our Team</span></a></li>
<li id="mobile-menu-item-815" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/contact/" class=""><span>Contact</span></a></li>
<li id="mobile-menu-item-915" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/faq/" class=""><span>FAQ</span></a></li>
<li id="mobile-menu-item-816" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/coming-soon/" class=""><span>Coming Soon</span></a></li>
<li id="mobile-menu-item-633" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/404" class=""><span>404</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-41" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Destinations</span></h6><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-312" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/destination-list/" class=""><span>Destination List</span></a></li>
<li id="mobile-menu-item-42" class="menu-item menu-item-type-post_type menu-item-object-destinations "><a href="https://wanderers.qodeinteractive.com/destinations/thailand/" class=""><span>Destination Item</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-43" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Tours</span></h6><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-86" class="menu-item menu-item-type-post_type menu-item-object-tour-item "><a href="https://wanderers.qodeinteractive.com/tour-item/ultimate-thailand/" class=""><span>Tour Single</span></a></li>
<li id="mobile-menu-item-319" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" mkdf-mobile-no-link"><span>Tour Lists</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-2273" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/tour-search-page/?view_type=standard" class=""><span>Standard</span></a></li>
<li id="mobile-menu-item-2274" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/tour-search-page/?view_type=gallery" class=""><span>Gallery</span></a></li>
<li id="mobile-menu-item-333" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/tour-list-carousel/" class=""><span>Carousel</span></a></li>
<li id="mobile-menu-item-2275" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/tour-search-page/?view_type=list" class=""><span>Search Page</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-1281" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" mkdf-mobile-no-link"><span>Dashboard</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1284" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/dashboard/?user-action=profile" class=""><span>My Profile</span></a></li>
<li id="mobile-menu-item-1282" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/dashboard/?user-action=edit-profile" class=""><span>Edit Profile</span></a></li>
<li id="mobile-menu-item-1283" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://wanderers.qodeinteractive.com/dashboard/?user-action=my-bookings" class=""><span>My Bookings</span></a></li>
</ul>
</li>
</ul>
</li>
<li id="mobile-menu-item-45" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Blog</span></h6><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-525" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/blog-list/" class=""><span>Standard List</span></a></li>
<li id="mobile-menu-item-625" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/blog-masonry/" class=""><span>Masonry List</span></a></li>
<li id="mobile-menu-item-516" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" mkdf-mobile-no-link"><span>Single</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-515" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/solo-traveler-learns-on-the-road/" class=""><span>Standard Post</span></a></li>
<li id="mobile-menu-item-547" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/new-ways-to-become-a-better-travel-blogger/" class=""><span>Gallery Post</span></a></li>
<li id="mobile-menu-item-546" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/use-your-social-network-to-travel/" class=""><span>Audio Post</span></a></li>
<li id="mobile-menu-item-543" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/travel-the-world-in-only-20-days/" class=""><span>Video Post</span></a></li>
<li id="mobile-menu-item-544" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/best-designed-wordpress-themes/" class=""><span>Link Post</span></a></li>
<li id="mobile-menu-item-545" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://wanderers.qodeinteractive.com/marc-nicolaus-richmond/" class=""><span>Quote Post</span></a></li>
</ul>
</li>
</ul>
</li>
<li id="mobile-menu-item-46" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Shop</span></h6><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-39" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/shop/" class=""><span>List</span></a></li>
<li id="mobile-menu-item-362" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://wanderers.qodeinteractive.com/shop/biking-helmet/" class=""><span>Single</span></a></li>
<li id="mobile-menu-item-47" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" mkdf-mobile-no-link"><span>Shop Pages</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-36" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/my-account/" class=""><span>My account</span></a></li>
<li id="mobile-menu-item-37" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/checkout/" class=""><span>Checkout</span></a></li>
<li id="mobile-menu-item-38" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/cart/" class=""><span>Cart</span></a></li>
</ul>
</li>
</ul>
</li>
<li id="mobile-menu-item-44" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Elements</span></h6><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1195" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" mkdf-mobile-no-link"><span>Featured</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1194" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tour-list-standard/" class=""><span>Tour List Standard</span></a></li>
<li id="mobile-menu-item-1409" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tour-list-gallery/" class=""><span>Tour List Gallery</span></a></li>
<li id="mobile-menu-item-1408" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tour-list-masonry/" class=""><span>Tour List Masonry</span></a></li>
<li id="mobile-menu-item-1419" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tour-carousel/" class=""><span>Tour Carousel</span></a></li>
<li id="mobile-menu-item-1539" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tour-filter/" class=""><span>Tour Filter</span></a></li>
<li id="mobile-menu-item-1499" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/destination-list-shortcode-2/" class=""><span>Destination List</span></a></li>
<li id="mobile-menu-item-1190" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/parallax-sections/" class=""><span>Parallax Sections</span></a></li>
<li id="mobile-menu-item-1189" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/video-button/" class=""><span>Video Button</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-1196" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" mkdf-mobile-no-link"><span>Classic</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1217" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/accordions-and-toogles/" class=""><span>Accordions &#038; Toogles</span></a></li>
<li id="mobile-menu-item-1229" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/tabs/" class=""><span>Tabs</span></a></li>
<li id="mobile-menu-item-1228" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/buttons/" class=""><span>Buttons</span></a></li>
<li id="mobile-menu-item-1216" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/icon-with-text/" class=""><span>Icon With Text</span></a></li>
<li id="mobile-menu-item-1839" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/icon-list/" class=""><span>Icon List</span></a></li>
<li id="mobile-menu-item-1226" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/google-maps/" class=""><span>Google Maps</span></a></li>
<li id="mobile-menu-item-1215" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/contact-form/" class=""><span>Contact Form</span></a></li>
<li id="mobile-menu-item-1213" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/clients/" class=""><span>Clients</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-1197" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" mkdf-mobile-no-link"><span>Infographic</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1255" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/counters/" class=""><span>Counters</span></a></li>
<li id="mobile-menu-item-1254" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/countdown/" class=""><span>Countdown</span></a></li>
<li id="mobile-menu-item-1248" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/progress-bar/" class=""><span>Progress Bar</span></a></li>
<li id="mobile-menu-item-1246" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/blog-list/" class=""><span>Blog List</span></a></li>
<li id="mobile-menu-item-1192" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/team/" class=""><span>Team</span></a></li>
<li id="mobile-menu-item-1214" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/top-reviews/" class=""><span>Top Reviews</span></a></li>
<li id="mobile-menu-item-1971" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/call-to-action/" class=""><span>Call To Action</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-1198" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" mkdf-mobile-no-link"><span>Typography</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1279" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/headings/" class=""><span>Headings</span></a></li>
<li id="mobile-menu-item-1278" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/columns/" class=""><span>Columns</span></a></li>
<li id="mobile-menu-item-1277" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/blockquote/" class=""><span>Blockquote</span></a></li>
<li id="mobile-menu-item-1276" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/dropcaps/" class=""><span>Dropcaps</span></a></li>
<li id="mobile-menu-item-1275" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/highlights/" class=""><span>Highlights</span></a></li>
<li id="mobile-menu-item-1274" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/separators/" class=""><span>Separators</span></a></li>
<li id="mobile-menu-item-1273" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/title-subtitle/" class=""><span>Title &#038; Subtitle</span></a></li>
<li id="mobile-menu-item-1272" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://wanderers.qodeinteractive.com/elements/custom-font/" class=""><span>Custom Font</span></a></li>
</ul>
</li>
</ul>
</li>
</ul> </div>
</nav>
</div>
<form action="https://wanderers.qodeinteractive.com/" class="mkdf-search-cover" method="get">
<div class="mkdf-container">
<div class="mkdf-container-inner clearfix">
<div class="mkdf-form-holder-outer">
<div class="mkdf-form-holder">
<div class="mkdf-form-holder-inner">
<span class="icon_search"></span>
<input type="text" placeholder="Search on site..." name="s" class="mkdf_search_field" autocomplete="off" />
<a class="mkdf-search-close" href="#">
<span aria-hidden="true" class="mkdf-icon-font-elegant icon_close "></span> </a>
</div>
</div>
</div>
</div>
</div>
</form></header>
<a id='mkdf-back-to-top' href='#'>
<span class="mkdf-icon-stack">
<i class="mkdf-icon-font-awesome fa fa-angle-up "></i> </span>
<span class="mkdf-icon-stack mkdf-btt-text">
Top </span>
</a>
<div class="mkdf-content" style="margin-top: -80px">
<div class="mkdf-content-inner"> <div class="mkdf-page-not-found">
<h1 class="mkdf-404-title">
404 </h1>
<h3 class="mkdf-404-subtitle">
How Did You Get Here? </h3>
<p class="mkdf-404-text">
</p>
<form role="search" method="get" class="searchform" id="searchform-233" action="https://wanderers.qodeinteractive.com/">
<label class="screen-reader-text">Search for:</label>
<div class="input-holder clearfix">
<input type="search" class="search-field" placeholder="Search..." value="" name="s" title="Search for:" />
<button type="submit" class="mkdf-search-submit"><span aria-hidden="true" class="mkdf-icon-font-elegant icon_search "></span></button>
</div>
</form> </div>
</div>
</div>
</div>
</div>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>
			window.RS_MODULES = window.RS_MODULES || {};
			window.RS_MODULES.modules = window.RS_MODULES.modules || {};
			window.RS_MODULES.waiting = window.RS_MODULES.waiting || [];
			window.RS_MODULES.defered = false;
			window.RS_MODULES.moduleWaiting = window.RS_MODULES.moduleWaiting || {};
			window.RS_MODULES.type = 'compiled';
		</script>
<div class="mkdf-login-register-holder">
<div class="mkdf-login-register-content">
<ul>
<li><a href="#mkdf-login-content">Login</a></li>
<li><a href="#mkdf-register-content">Register</a></li>
</ul>
<div class="mkdf-login-content-inner" id="mkdf-login-content">
<div class="mkdf-wp-login-holder"><div class="mkdf-social-login-holder">
<div class="mkdf-social-login-holder-inner">
<form method="post" class="mkdf-login-form">
<p class="mkdf-membership-popup-title">Wanderers</p>
<fieldset>
<div>
<i class="mkdf-popup-icon ion-person"></i>
<input type="text" name="user_login_name" id="user_login_name" placeholder="User Name" value="" required pattern=".{3,}" title="Three or more characters" />
</div>
<div class="mkdf-login-pw">
<i class="mkdf-popup-icon ion-unlocked"></i>
<input type="password" name="user_login_password" id="user_login_password" placeholder="Password" value="" required />
</div>
<div class="mkdf-lost-pass-remember-holder clearfix">
<span class="mkdf-login-remember">
<input name="rememberme" value="forever" id="rememberme" type="checkbox" />
<label for="rememberme" class="mkdf-checbox-label">Remember me</label>
</span>
</div>
<a href="https://wanderers.qodeinteractive.com/my-account/lost-password/" class="mkdf-login-action-btn" data-el="#mkdf-reset-pass-content" data-title="Lost Password?">Lost Your password?</a>
<input type="hidden" name="redirect" id="redirect" value="">
<div class="mkdf-login-button-holder">
<button type="submit" class="mkdf-btn mkdf-btn-small mkdf-btn-solid"> <span class="mkdf-btn-text">Login</span> </button> <input type="hidden" id="mkdf-login-security" name="mkdf-login-security" value="a5c28f4b17" /><input type="hidden" name="_wp_http_referer" value="/typeahead.js" /> </div>
</fieldset>
</form>
</div>
<div class="mkdf-membership-response-holder clearfix"></div><script type="text/template" class="mkdf-membership-response-template">
					<div class="mkdf-membership-response <%= messageClass %> ">
						<div class="mkdf-membership-response-message">
							<p><%= message %></p>
						</div>
					</div>
				</script></div></div>
</div>
<div class="mkdf-register-content-inner" id="mkdf-register-content">
<div class="mkdf-wp-register-holder"><div class="mkdf-social-register-holder">
<form method="post" class="mkdf-register-form">
<p class="mkdf-membership-popup-title">Wanderers</p>
<fieldset>
<div>
<i class="mkdf-popup-icon ion-person"></i>
<input type="text" name="user_register_name" id="user_register_name" placeholder="User Name" value="" required pattern=".{3,}" title="Three or more characters" />
</div>
<div>
<i class="mkdf-popup-icon ion-email"></i>
<input type="email" name="user_register_email" id="user_register_email" placeholder="Email" value="" required />
</div>
<div>
<i class="mkdf-popup-icon ion-unlocked"></i>
<input type="password" name="user_register_password" id="user_register_password" placeholder="Password" value="" required />
</div>
<div>
<i class="mkdf-popup-icon ion-unlocked"></i>
<input type="password" name="user_register_confirm_password" id="user_register_confirm_password" placeholder="Repeat Password" value="" required />
</div>
<div class="mkdf-register-button-holder">
<button type="submit" class="mkdf-btn mkdf-btn-small mkdf-btn-solid"> <span class="mkdf-btn-text">Register</span> </button><input type="hidden" id="mkdf-register-security" name="mkdf-register-security" value="6c1bcc120b" /><input type="hidden" name="_wp_http_referer" value="/typeahead.js" /> </div>
</fieldset>
</form>
<div class="mkdf-membership-response-holder clearfix"></div><script type="text/template" class="mkdf-membership-response-template">
					<div class="mkdf-membership-response <%= messageClass %> ">
						<div class="mkdf-membership-response-message">
							<p><%= message %></p>
						</div>
					</div>
				</script></div></div>
</div>
</div>
</div><div class="rbt-toolbar" data-theme="Wanderers" data-featured="" data-button-position="62%" data-button-horizontal="right" data-button-alt="no"></div>

<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KTQ2BTD"
height="0" width="0" style="display:none;visibility:hidden" aria-hidden="true"></iframe></noscript>
 <script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
<link rel='stylesheet' id='js_composer_front-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=6.8.0' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css' href='https://wanderers.qodeinteractive.com/wp-content/plugins/revslider/public/assets/css/rs6.css?ver=6.5.12' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.13.7' id='regenerator-runtime-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0' id='wp-polyfill-js'></script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/wanderers.qodeinteractive.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.5.3' id='contact-form-7-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-includes/js/underscore.min.js?ver=1.13.1' id='underscore-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-includes/js/jquery/ui/core.min.js?ver=1.12.1' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-includes/js/jquery/ui/tabs.min.js?ver=1.12.1' id='jquery-ui-tabs-js'></script>
<script type='text/javascript' id='wanderers-mkdf-modules-js-extra'>
/* <![CDATA[ */
var mkdfGlobalVars = {"vars":{"mkdfAddForAdminBar":0,"mkdfElementAppearAmount":-100,"mkdfAjaxUrl":"https:\/\/wanderers.qodeinteractive.com\/wp-admin\/admin-ajax.php","mkdfStickyHeaderHeight":70,"mkdfStickyHeaderTransparencyHeight":70,"mkdfTopBarHeight":0,"mkdfLogoAreaHeight":0,"mkdfMenuAreaHeight":80,"mkdfMobileHeaderHeight":70}};
var mkdfPerPageVars = {"vars":{"mkdfStickyScrollAmount":0,"mkdfHeaderTransparencyHeight":0,"mkdfHeaderVerticalWidth":0}};
/* ]]> */
</script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/js/modules.min.js?ver=5.8.2' id='wanderers-mkdf-modules-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/mkdf-membership/assets/js/membership.min.js?ver=5.8.2' id='wanderers-mikado-membership-script-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/mkdf-tours/assets/js/modules/plugins/nouislider.min.js?ver=5.8.2' id='nouislider-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/mkdf-tours/assets/js/modules/plugins/typeahead.bundle.min.js?ver=5.8.2' id='typeahead-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/mkdf-tours/assets/js/modules/plugins/bloodhound.min.js?ver=5.8.2' id='bloodhound-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/mkdf-tours/assets/js/modules/plugins/select2.min.js?ver=5.8.2' id='select2-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-includes/js/jquery/ui/datepicker.min.js?ver=1.12.1' id='jquery-ui-datepicker-js'></script>
<script type='text/javascript' id='jquery-ui-datepicker-js-after'>
jQuery(document).ready(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"Close","currentText":"Today","monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Previous","dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"dateFormat":"MM d, yy","firstDay":1,"isRTL":false});});
</script>
<script type='text/javascript' id='wanderers-mikado-tours-script-js-extra'>
/* <![CDATA[ */
var mkdfToursSearchData = {"tours":["Ultimate Thailand","Discover India","Forest Adventure","China Tour","Safari Tour","Canada Tour","Pyramids Tour","Mexico Explore","Europe Tour","Berlin Tour","Budapest Tour","Highlights Rome","Diving Adventure","Reindeer Lake","Slovenia Wildlife","European History","Wild Lakes","Seaside Adventure","Discover Rome","Hungary Tour","Germany Tour","City Tour","Explore Mexico","Egypt Tour","Discover Thailand","Exotic Adventure","India Tour","Eastern Tour","Desert Tour","Wildlife Tour","Antique Europe","Awesome Mexico","Ancient Pyramids","Adventure Alaska","Action Safari","Asian Dicovery"],"destinations":["Canada","Mexico","Europe","Japan","China","Thailand","India","Africa"]};
/* ]]> */
</script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/mkdf-tours/assets/js/tours.min.js?ver=5.8.2' id='wanderers-mikado-tours-script-js'></script>
<script type='text/javascript' src='https://export.qodethemes.com/_toolbar/assets/js/rbt-modules.js?ver=5.8.2' id='rabbit_js-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.6.0.0' id='js-cookie-js'></script>
<script type='text/javascript' id='woocommerce-js-extra'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=6.0.0' id='woocommerce-js'></script>
<script type='text/javascript' id='wc-cart-fragments-js-extra'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_c4bb1d6017b4ab235cffcc8592fbc539","fragment_name":"wc_fragments_c4bb1d6017b4ab235cffcc8592fbc539","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=6.0.0' id='wc-cart-fragments-js'></script>
<script type='text/javascript' id='ppress-frontend-script-js-extra'>
/* <![CDATA[ */
var pp_ajax_form = {"ajaxurl":"https:\/\/wanderers.qodeinteractive.com\/wp-admin\/admin-ajax.php","confirm_delete":"Are you sure?","deleting_text":"Deleting...","deleting_error":"An error occurred. Please try again.","nonce":"34e49898f5","disable_ajax_form":"false"};
/* ]]> */
</script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/js/frontend.min.js?ver=3.2.5' id='ppress-frontend-script-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/duracelltomi-google-tag-manager/js/gtm4wp-form-move-tracker.js?ver=1.14.1' id='gtm4wp-form-move-tracker-js'></script>
<script type='text/javascript' id='qi-addons-for-elementor-script-js-extra'>
/* <![CDATA[ */
var qodefQiAddonsGlobal = {"vars":{"adminBarHeight":0,"iconArrowLeft":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 34.2 32.3\" xml:space=\"preserve\" style=\"stroke-width: 2;\"><line x1=\"0.5\" y1=\"16\" x2=\"33.5\" y2=\"16\"\/><line x1=\"0.3\" y1=\"16.5\" x2=\"16.2\" y2=\"0.7\"\/><line x1=\"0\" y1=\"15.4\" x2=\"16.2\" y2=\"31.6\"\/><\/svg>","iconArrowRight":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 34.2 32.3\" xml:space=\"preserve\" style=\"stroke-width: 2;\"><line x1=\"0\" y1=\"16\" x2=\"33\" y2=\"16\"\/><line x1=\"17.3\" y1=\"0.7\" x2=\"33.2\" y2=\"16.5\"\/><line x1=\"17.3\" y1=\"31.6\" x2=\"33.5\" y2=\"15.4\"\/><\/svg>","iconClose":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 9.1 9.1\" xml:space=\"preserve\"><g><path d=\"M8.5,0L9,0.6L5.1,4.5L9,8.5L8.5,9L4.5,5.1L0.6,9L0,8.5L4,4.5L0,0.6L0.6,0L4.5,4L8.5,0z\"\/><\/g><\/svg>"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/js/main.min.js?ver=5.8.2' id='qi-addons-for-elementor-script-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-includes/js/jquery/ui/accordion.min.js?ver=1.12.1' id='jquery-ui-accordion-js'></script>
<script type='text/javascript' id='mediaelement-core-js-before'>
var mejsL10n = {"language":"en","strings":{"mejs.download-file":"Download File","mejs.install-flash":"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen":"Fullscreen","mejs.play":"Play","mejs.pause":"Pause","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.","mejs.live-broadcast":"Live Broadcast","mejs.volume-help-text":"Use Up\/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.captions-subtitles":"Captions\/Subtitles","mejs.captions-chapters":"Chapters","mejs.none":"None","mejs.afrikaans":"Afrikaans","mejs.albanian":"Albanian","mejs.arabic":"Arabic","mejs.belarusian":"Belarusian","mejs.bulgarian":"Bulgarian","mejs.catalan":"Catalan","mejs.chinese":"Chinese","mejs.chinese-simplified":"Chinese (Simplified)","mejs.chinese-traditional":"Chinese (Traditional)","mejs.croatian":"Croatian","mejs.czech":"Czech","mejs.danish":"Danish","mejs.dutch":"Dutch","mejs.english":"English","mejs.estonian":"Estonian","mejs.filipino":"Filipino","mejs.finnish":"Finnish","mejs.french":"French","mejs.galician":"Galician","mejs.german":"German","mejs.greek":"Greek","mejs.haitian-creole":"Haitian Creole","mejs.hebrew":"Hebrew","mejs.hindi":"Hindi","mejs.hungarian":"Hungarian","mejs.icelandic":"Icelandic","mejs.indonesian":"Indonesian","mejs.irish":"Irish","mejs.italian":"Italian","mejs.japanese":"Japanese","mejs.korean":"Korean","mejs.latvian":"Latvian","mejs.lithuanian":"Lithuanian","mejs.macedonian":"Macedonian","mejs.malay":"Malay","mejs.maltese":"Maltese","mejs.norwegian":"Norwegian","mejs.persian":"Persian","mejs.polish":"Polish","mejs.portuguese":"Portuguese","mejs.romanian":"Romanian","mejs.russian":"Russian","mejs.serbian":"Serbian","mejs.slovak":"Slovak","mejs.slovenian":"Slovenian","mejs.spanish":"Spanish","mejs.swahili":"Swahili","mejs.swedish":"Swedish","mejs.tagalog":"Tagalog","mejs.thai":"Thai","mejs.turkish":"Turkish","mejs.ukrainian":"Ukrainian","mejs.vietnamese":"Vietnamese","mejs.welsh":"Welsh","mejs.yiddish":"Yiddish"}};
</script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=4.2.16' id='mediaelement-core-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-includes/js/mediaelement/mediaelement-migrate.min.js?ver=5.8.2' id='mediaelement-migrate-js'></script>
<script type='text/javascript' id='mediaelement-js-extra'>
/* <![CDATA[ */
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive"};
/* ]]> */
</script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=5.8.2' id='wp-mediaelement-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/js/modules/plugins/jquery.appear.js?ver=5.8.2' id='appear-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/js/modules/plugins/modernizr.min.js?ver=5.8.2' id='modernizr-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-includes/js/hoverIntent.min.js?ver=1.10.1' id='hoverIntent-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/js/modules/plugins/jquery.plugin.js?ver=5.8.2' id='jquery-plugin-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/js/modules/plugins/owl.carousel.min.js?ver=5.8.2' id='owl-carousel-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/js/modules/plugins/jquery.waypoints.min.js?ver=5.8.2' id='waypoints-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/js/modules/plugins/fluidvids.min.js?ver=5.8.2' id='fluidvids-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/js_composer/assets/lib/prettyphoto/js/jquery.prettyPhoto.min.js?ver=6.8.0' id='prettyphoto-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/js/modules/plugins/perfect-scrollbar.jquery.min.js?ver=5.8.2' id='perfect-scrollbar-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/js/modules/plugins/ScrollToPlugin.min.js?ver=5.8.2' id='ScrollToPlugin-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/js/modules/plugins/parallax.min.js?ver=5.8.2' id='parallax-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/js/modules/plugins/jquery.waitforimages.js?ver=5.8.2' id='waitforimages-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/themes/wanderers/assets/js/modules/plugins/jquery.easing.1.3.js?ver=5.8.2' id='jquery-easing-1.3-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/js_composer/assets/lib/bower/isotope/dist/isotope.pkgd.min.js?ver=6.8.0' id='isotope-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/inc/masonry/assets/js/plugins/packery-mode.pkgd.min.js?ver=5.8.2' id='packery-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/mkdf-core/shortcodes/countdown/assets/js/plugins/jquery.countdown.min.js?ver=5.8.2' id='countdown-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/mkdf-core/shortcodes/counter/assets/js/plugins/counter.js?ver=5.8.2' id='counter-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/mkdf-core/shortcodes/counter/assets/js/plugins/absoluteCounter.min.js?ver=5.8.2' id='absoluteCounter-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/inc/shortcodes/typeout-text/assets/js/plugins/typed.js?ver=1' id='typed-js'></script>
<script type='text/javascript' src='//maps.googleapis.com/maps/api/js?key=AIzaSyCu2ZqQ6gUf2mksmL6LDmHpMy0uFjDKQYQ&#038;ver=5.8.2' id='wanderers-mkdf-google-map-api-js'></script>
<script type="text/javascript" src="https://static.zdassets.com/ekr/snippet.js?key=af3078fd-a5ae-40da-bee0-e589b98c8603&#038;ver=5.8.2" id="ze-snippet"></script><script type="text/javascript">
						zE(function(){
							$zopim(function(){
								var isChatEnabled = sessionStorage.getItem("qodeChatEnabled"),
									appearingTime = 15000;
								
								if(isChatEnabled !== "no") {
									setTimeout(function(){
										$zopim.livechat.window.show();
										
										 $zopim.livechat.window.onHide(function(){
										    sessionStorage.setItem("qodeChatEnabled", "no");
										 });
									}, appearingTime);
								}
							});
						});
						</script><script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-includes/js/wp-embed.min.js?ver=5.8.2' id='wp-embed-js'></script>
<script type='text/javascript' src='https://wanderers.qodeinteractive.com/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=6.8.0' id='wpb_composer_front_js-js'></script>
</body>
</html>